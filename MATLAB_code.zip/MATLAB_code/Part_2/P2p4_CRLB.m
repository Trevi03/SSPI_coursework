clc
clear

% load the data
load NASDAQ.mat
prices= NASDAQ.Close;
time = NASDAQ.Date;
prices_norm = zscore(prices);

%% plot the CRLB

%From original series
Rx = xcorr(prices,'unbiased');
Rx0 = max(Rx);

%From standardised series
Rx_std = xcorr(prices_norm,'unbiased');
Rx0_std=max(Rx_std);

i=1;
% number of data points N
for N=1:50:1001 
    j=1;
    % true variance of the driving noise in the right hand side
    for var_n = 1:50:1001
        crlb_var(i,j)=(2*var_n^2)/N;
        crlb_a(i,j)=(var_n)/(N*Rx0_std);
        j=j+1;  
    end
    i=i+1;
end
N=1:50:1001;
var_n = 1:50:1001;
%%
figure; 
%Plot CRLB
subplot(1,2,1)
hm_var = heatmap(var_n,N,log10(crlb_var),'Colormap', cool, 'ColorbarVisible', 'on');
title('CRLB for \sigma^2 estimate of driving noise')
xlabel('Noise Variance')
ylabel('N')
subplot(1,2,2)
hm_a = heatmap(var_n,N,log10(crlb_a),'Colormap', cool,'ColorbarVisible', 'on');
title('CRLB for \alpha_1 estimate')
xlabel('Noise Variance')
ylabel('N')
%%
PSD_AR = pyulear(prices,1);
figure;
plot(PSD_AR)
