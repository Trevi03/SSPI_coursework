clc
clear
close all


load("trial1.mat");
load("trial2.mat");
load("trial3.mat");
load("data.mat");

% fs = 500; %Hz
% [xRRI_trial1,fsRRI]=ECG_to_RRI(data1,fs);
% [xRRI_trial2,fsRRI]=ECG_to_RRI(data2,fs);
% [xRRI_trial3,fsRRI]=ECG_to_RRI(data3,fs);
%% Heart rate probability density estimate (PDE)

hr_orig_trial1 = 60./xRRI_trial1;
hr_orig_trial2 = 60./xRRI_trial2;
hr_orig_trial3 = 60./xRRI_trial3;

[f,xi]=ksdensity(hr_orig_trial3);

a1=1;
a2=0.6;


avg_hr_a1=[];
avg_hr_a2=[];

%Averaging every 10 samples of heart rate.
window=5;
for i=1:((length(hr_orig_trial3)/window))
    avg_hr_a1(i)=a1*mean(hr_orig_trial3(((i-1)*window+1):((i*window))));
    avg_hr_a2(i)= a2*mean(hr_orig_trial3(((i-1)*window+1):((i*window))));
end

%Obtaining PDE's
[f_a1,xi_a1]=ksdensity(avg_hr_a1);
[f_a2,xi_a2]=ksdensity(avg_hr_a2);

figure;
hold on
plot(xi,f,'LineWidth', 2);
plot(xi_a1,f_a1,'LineWidth', 2);
plot(xi_a2,f_a2,'LineWidth', 2);
title('Probability Density Estimates of heart rates');
xlabel('Heart Rate (beats/min)'); 
ylabel('Probability');
legend('Original HR','Average HR with a=1','Average HR with a=0.6')

%% AR modelling of heart rate
% Make data zero-mean
zmean_xRRI_trial1 = detrend(xRRI_trial1);
zmean_xRRI_trial2 = detrend(xRRI_trial2);
zmean_xRRI_trial3 = detrend(xRRI_trial3);

[ACF_trial1,timelag_1] = xcorr(zmean_xRRI_trial1,'unbiased');
[ACF_trial2,timelag_2] = xcorr(zmean_xRRI_trial2,'unbiased');
[ACF_trial3,timelag_3] = xcorr(zmean_xRRI_trial3,'unbiased');

%Plotting the ACF
figure;
subplot(3,1,1)
plot(timelag_1,ACF_trial1,'b','Linewidth',1);
title('ACF estimate trial 1'); 
ylabel('Correlation R(\tau)');
xlabel('Time Lag (\tau)');
xlim([-100 100])
grid on

subplot(3,1,2)
plot(timelag_2,ACF_trial2,'r','Linewidth',1);
title('ACF estimate trial 2'); 
ylabel('Correlation R(\tau)');
xlabel('Time Lag (\tau)');
xlim([-100 100])
grid on

subplot(3,1,3)
plot(timelag_3,ACF_trial3,'g','Linewidth',1);
title('ACF estimate trial 3'); 
ylabel('Correlation R(\tau)');
xlabel('Time Lag (\tau)');
xlim([-100 100])
grid on

%%
% closer look

conf95 = sqrt(2)*erfinv(0.95)/sqrt(length(ACF_trial1));

figure;
subplot(1,3,1)
stem(timelag_1,ACF_trial1,'b','Linewidth',1);
% hold on
% plot(xlim,[1 1]'*[-conf95 conf95],'r--','HandleVisibility','off')
title('ACF estimate trial 1'); 
ylabel('Correlation R(\tau)');
xlabel('Time Lag (\tau)');
xlim([0 15])
grid on

conf95 = sqrt(2)*erfinv(0.95)/sqrt(length(ACF_trial2));

subplot(1,3,2)
stem(timelag_2,ACF_trial2,'r','Linewidth',1);
% hold on
% plot(xlim,[1 1]'*[-conf95 conf95],'r--','HandleVisibility','off')
title('ACF estimate trial 2'); 
ylabel('Correlation R(\tau)');
xlabel('Time Lag (\tau)');
xlim([0 15])
grid on

conf95 = sqrt(2)*erfinv(0.95)/sqrt(length(ACF_trial3));

subplot(1,3,3)
stem(timelag_3,ACF_trial3,'g','Linewidth',1);
% hold on
% plot(xlim,[1 1]'*[-conf95 conf95],'r--','HandleVisibility','off')
title('ACF estimate trial 3'); 
ylabel('Correlation R(\tau)');
xlabel('Time Lag (\tau)');
xlim([0 15])
grid on

%%
p=10;            % the number of estimated parameters (model order)

N1 = size(zmean_xRRI_trial1,1); % the number of available data points
E1  = zeros(1,p); % the loss function (typically cumulative squared error)
AIC_c1 = zeros(1,p);
MDL1 = zeros(1,p);
AIC1 = zeros(1,p);
for i =1:10 
    [a,E1(i)] = aryule(zmean_xRRI_trial1,i); %first component of a is 1 which is our a0.
    MDL1(i) = log10(E1(i)) + ((i*log10(N1))/N1); %Minimum description length
    AIC1(i) = log10(E1(i)) + (2*i)/N1; %Akaike information criterion
    AIC_c1(i) =  AIC1(i) + (((2*i)*(i+1))/(N1-i-1)); %Corrected AIC 
end

N2 = size(zmean_xRRI_trial2,1); % the number of available data points
E2  = zeros(1,p); % the loss function (typically cumulative squared error)
AIC_c2 = zeros(1,p);
MDL2 = zeros(1,p);
AIC2 = zeros(1,p);
for i =1:10 
    [a,E2(i)] = aryule(zmean_xRRI_trial2,i); %first component of a is 1 which is our a0.
    MDL2(i) = log10(E2(i)) + ((i*log10(N2))/N2); %Minimum description length
    AIC2(i) = log10(E2(i)) + (2*i)/N2; %Akaike information criterion
    AIC_c2(i) =  AIC2(i) + (((2*i)*(i+1))/(N2-i-1)); %Corrected AIC 
end

N3 = size(zmean_xRRI_trial3,1); % the number of available data points
E3  = zeros(1,p); % the loss function (typically cumulative squared error)
AIC_c3 = zeros(1,p);
MDL3 = zeros(1,p);
AIC3 = zeros(1,p);
for i =1:10 
    [a,E3(i)] = aryule(zmean_xRRI_trial3,i); %first component of a is 1 which is our a0.
    MDL3(i) = log10(E3(i)) + ((i*log10(N3))/N3); %Minimum description length
    AIC3(i) = log10(E3(i)) + (2*i)/N3; %Akaike information criterion
    AIC_c3(i) =  AIC3(i) + (((2*i)*(i+1))/(N3-i-1)); %Corrected AIC 
end


figure;
subplot(1,3,1)

hold on;
plot(AIC1,'DisplayName','AIC',LineWidth=0.8);
plot(MDL1,'DisplayName','MDL',LineWidth=0.8);
plot(AIC_c1,'DisplayName','AIC_c',LineWidth=0.8);
axis([1 10 -5 20]);
grid on;
xlabel('Model Order p');
ylabel('Magnitude');
title('AIC, MDL and AIC_c for trial 1');
legend('show');

subplot(1,3,2)
hold on;
plot(AIC2,'DisplayName','AIC',LineWidth=0.8);
plot(MDL2,'DisplayName','MDL',LineWidth=0.8);
plot(AIC_c2,'DisplayName','AIC_c',LineWidth=0.8);
axis([1 10 -5 20]);
grid on;
xlabel('Model Order p');
ylabel('Magnitude');
title('AIC, MDL and AIC_c for trial 2');
legend('show');

subplot(1,3,3)
hold on;
plot(AIC3,'DisplayName','AIC',LineWidth=0.8);
plot(MDL3,'DisplayName','MDL',LineWidth=0.8);
plot(AIC_c3,'DisplayName','AIC_c',LineWidth=0.8);
axis([1 10 -5 20]);
grid on;
xlabel('Model Order p');
ylabel('Magnitude');
title('AIC, MDL and AIC_c for trial 3');
legend('show');

%% get numerical minimum
[MDL_min, MDl_order] = min(MDL1);
[AIC_min, AIC_order] = min(AIC1);
[AICc_min, AICc_order] = min(AIC_c1);

disp('Trial 1')
disp(['min MDL: ',num2str(MDL_min),' , order number: ', num2str(MDl_order)])
disp(['min AIC: ',num2str(AIC_min),' , order number: ', num2str(AIC_order)])
disp(['min AIC_c: ',num2str(AICc_min),' , order number: ', num2str(AICc_order)])

[MDL_min, MDl_order] = min(MDL2);
[AIC_min, AIC_order] = min(AIC2);
[AICc_min, AICc_order] = min(AIC_c2);

disp('Trial 2')
disp(['min MDL: ',num2str(MDL_min),' , order number: ', num2str(MDl_order)])
disp(['min AIC: ',num2str(AIC_min),' , order number: ', num2str(AIC_order)])
disp(['min AIC_c: ',num2str(AICc_min),' , order number: ', num2str(AICc_order)])

[MDL_min, MDl_order] = min(MDL3);
[AIC_min, AIC_order] = min(AIC3);
[AICc_min, AICc_order] = min(AIC_c3);

disp('Trial 3')
disp(['min MDL: ',num2str(MDL_min),' , order number: ', num2str(MDl_order)])
disp(['min AIC: ',num2str(AIC_min),' , order number: ', num2str(AIC_order)])
disp(['min AIC_c: ',num2str(AICc_min),' , order number: ', num2str(AICc_order)])


%%
[PACF_t1, timelags1] = parcorr(zmean_xRRI_trial1,'Method','Yule-Walker','NumLags',10);
[PACF_t2, timelags2] = parcorr(zmean_xRRI_trial2,'Method','Yule-Walker','NumLags',10);
[PACF_t3, timelags3] = parcorr(zmean_xRRI_trial3,'Method','Yule-Walker','NumLags',10);

figure;
subplot(3,1,1)
conf95 = std(PACF_t1)*erfinv(0.95)/sqrt(10);
stem(timelags1,PACF_t1,'b','Linewidth',1);
hold on
plot(xlim,[1 1]'*[-conf95 conf95],'k--','HandleVisibility','off')
title('PACF estimate trial 1'); 
ylabel('Correlation R(\tau)');
xlabel('Time Lag (\tau)');
grid on

subplot(3,1,2)
conf95 = std(PACF_t2)*erfinv(0.95)/sqrt(10);
stem(timelags2,PACF_t2,'r','Linewidth',1);
hold on
plot(xlim,[1 1]'*[-conf95 conf95],'k--','HandleVisibility','off')
title('PACF estimate trial 2'); 
ylabel('Correlation R(\tau)');
xlabel('Time Lag (\tau)');
grid on

subplot(3,1,3)
conf95 = std(PACF_t3)*erfinv(0.95)/sqrt(10);
stem(timelags3,PACF_t3,'g','Linewidth',1);
hold on
plot(xlim,[1 1]'*[-conf95 conf95],'k--','HandleVisibility','off')
title('PACF estimate trial 3'); 
ylabel('Correlation R(\tau)');
xlabel('Time Lag (\tau)');
grid on

