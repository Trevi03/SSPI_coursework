function [periodogram,freq_ax] = pgm(input_sequence)
% Periodogram - estimated PSD based on the fast Fourier transform (FFT)
%   periodogram = array of length N
%   freq_ax = normalised frequencies, of length N

N = length(input_sequence);
freq_ax = 0:1/N:(N-1)/N;
periodogram = zeros(1,N); % length of array freq, which is N

% calculate periodogram
ind = 1;
% loop for each frequency
for f=0:N-1
    insum = 0;
    % loop for each n
    for n=0:N-1
        insum = insum + input_sequence(n+1)*exp(-2j*pi*f*(n/N));
    end
    periodogram(ind)= (1/N)*(abs(insum)^2);
    ind = ind+1;
end
end