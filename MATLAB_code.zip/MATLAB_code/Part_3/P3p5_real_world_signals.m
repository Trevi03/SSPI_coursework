clc
clear all
close all

load("data.mat")
%% standard and averaged pgm estimate

% make data zero-mean
RRItrial1 = detrend(xRRI_trial1);
RRItrial2  = detrend(xRRI_trial2);
RRItrial3  = detrend(xRRI_trial3);

% Applying standard periodogram
[pgm_trial1, freq_trial1]=pgm(RRItrial1);
[pks,~] = findpeaks(pgm_trial1(1:ceil(length(pgm_trial1)/2)));
[max,~]=maxk(pks,2);
freqs(1)=find(pgm_trial1(1:ceil(length(pgm_trial1)/2))==max(1));
freqs(2)=find(pgm_trial1(1:ceil(length(pgm_trial1)/2))==max(2));
freq_peaks(1,1)=freq_trial1(freqs(2));
freq_peaks(1,2)=freq_trial1(freqs(1));

[pgm_trial2, freq_trial2]=pgm(RRItrial2);
[pks,~] = findpeaks(pgm_trial2(1:ceil(length(pgm_trial2)/2)));
[max,~]=maxk(pks,2);
freqs(1)=find(pgm_trial2(1:ceil(length(pgm_trial2)/2))==max(1));
freqs(2)=find(pgm_trial2(1:ceil(length(pgm_trial2)/2))==max(2));
freq_peaks(2,1)=freq_trial2(freqs(1));
freq_peaks(2,2)=freq_trial2(freqs(2));

[pgm_trial3, freq_trial3]=pgm(RRItrial3);
[pks,~] = findpeaks(pgm_trial3(1:ceil(length(pgm_trial3)/2)));
[max,~]=maxk(pks,2);
freqs(1)=find(pgm_trial3(1:ceil(length(pgm_trial3)/2))==max(1));
freqs(2)=find(pgm_trial3(1:ceil(length(pgm_trial3)/2))==max(2));
freq_peaks(3,1)=freq_trial3(freqs(1));
freq_peaks(3,2)=freq_trial3(freqs(2));

%Plotting standard periodogram
figure;
subplot(1,3,1)
plot(freq_trial1,pgm_trial1,'Linewidth',1)
xlabel('Normalised Frequency')
ylabel('PSD estimate')
xlim([0 0.2])
title('Standard Periodogram for Trial 1')
grid on

subplot(1,3,2)
plot(freq_trial2,pgm_trial2,'Linewidth',1)
xlabel('Normalised Frequency')
ylabel('PSD estimate')
xlim([0 0.2])
title('Standard Periodogram for Trial 2')
grid on

subplot(1,3,3)
plot(freq_trial3,pgm_trial3,'Linewidth',1)
xlabel('Normalised Frequency')
ylabel('PSD estimate')
xlim([0 0.2])
title('Standard Periodogram for Trial 3')
grid on

%% Averaged periodogram

N1=length(RRItrial1);
N2=length(RRItrial2);
N3=length(RRItrial3);

%Trial 1
figure;
index=1;
win_sz = [50 150];
place=0;
for sz = win_sz
    segm=[];
    P_segm=[];
    f_segm=[];
    
    n_segments = floor(N1/sz);
    
    for i=1:n_segments
        segm(i,:) = RRItrial1((((i-1)*sz)+1):(i*sz));
        %Computing the PSD estimate of each segment
        [P_segm(i,:),f_segm(i,:)]=pgm(segm(i,:));
    end
    % Averaged periodogram
    %This will take the average value of each column of our matrix
    avg_periodogram = mean(P_segm);
    
    subplot(2,3,(index+place))
    plot(f_segm(1,:),avg_periodogram,'Linewidth',1)
    xlabel('Normalised Frequency')
    ylabel('PSD est')
    title(['Trial 1 - Window Length=' num2str(sz)])
    grid on
    xlim([0 0.2])
    place=place+3;
end
index=index+1;
place=0;

%Trial 2
for sz = win_sz
    segm=[];
    P_segm=[];
    f_segm=[];
    
    n_segments = floor(N2/sz);
    
    for i=1:n_segments
        segm(i,:) = RRItrial2((((i-1)*sz)+1):(i*sz));
        %Computing the PSD estimate of each segment
        [P_segm(i,:),f_segm(i,:)]=pgm(segm(i,:));
    end
    % Averaged periodogram
    %This will take the average value of each column of our matrix
    avg_periodogram = mean(P_segm);
    
    subplot(2,3,(index+place))
    plot(f_segm(1,:),avg_periodogram,'Linewidth',1)
    xlabel('Normalised Frequency')
    ylabel('PSD est')
    title(['Trial 2 - Window Length=' num2str(sz)])
    grid on
    xlim([0 0.2])
    place=place+3;
end
index=index+1;
place=0;


%Trial 3
for sz = win_sz
    segm=[];
    P_segm=[];
    f_segm=[];
    
    n_segments = floor(N3/sz);
    
    for i=1:n_segments
        segm(i,:) = RRItrial3((((i-1)*sz)+1):(i*sz));
        %Computing the PSD estimate of each segment
        [P_segm(i,:),f_segm(i,:)]=pgm(segm(i,:));
    end
    % Averaged periodogram
    %This will take the average value of each column of our matrix
    avg_periodogram = mean(P_segm);
    
    subplot(2,3,(index+place))
    plot(f_segm(1,:),avg_periodogram,'Linewidth',1)
    xlabel('Normalised Frequency')
    ylabel('PSD est')
    title(['Trial 3 - Window Length=' num2str(sz)])
    grid on
    xlim([0 0.2])
    place=place+3;
end
