clc
clear
close all

%% Generate x and y
x = randn(1,1064);
y=filter([1],[1 0.9],x);
% remove the first 40 values affected by the transient effects of filter
y = y(41:length(y));

mean_x = mean(x);
mean_y = mean(y);
var_x = var(x);
var_y = var(y);

disp(['x: mean = ',num2str(mean_x),'  var = ',num2str(var_x)])
disp(['y: mean = ',num2str(mean_y),'  var = ',num2str(var_y)])

figure;
subplot(1,2,1)
plot(x,'Linewidth',1)
xlabel('Sample Index');
ylabel('Magnitude');
title('Filter Input Signal (x)')
xlim([0 length(x)])

subplot(1,2,2)
plot(y,'Color',"#D95319",'Linewidth',1)
xlabel('Sample Index');
ylabel('Magnitude');
title('Filter output Signal (y)')
xlim([0 length(y)])

%% exact PSD of the considered filtered signal
[h,w]=freqz([1],[1 0.9],512);
figure;
plot(w/(2*pi),abs(h).^2,'Color',"#0072BD",'LineWidth',1)
%%
[pgm_y, freq_y] = pgm(y);

figure;
subplot(1,2,1)
plot(freq_y,pgm_y,'Color',"#D95319",'LineWidth',0.8)
hold on
plot(w/(2*pi),abs(h).^2,'Color',"#0072BD",'LineWidth',1)
xlim([0 0.5])
xlabel('Normalised frequency')
ylabel('PSD estimate')
title('periodogram of y')
grid on

subplot(1,2,2)
plot(freq_y,pgm_y,'Color',"#D95319",'LineWidth',0.8,'DisplayName','estimated PSD')
hold on
plot(w/(2*pi),abs(h).^2,'Color',"#0072BD",'LineWidth',1,'DisplayName','exact PSD')
xlim([0.4 0.5])
xlabel('Normalised frequency')
ylabel('PSD estimate')
title('zoomed in periodogram of y')
grid on
legend

%% model-based PSD estimate
[ac_y,lag_y] = xcorr(y,'unbiased');

ind0 = find(lag_y==0);
ind1 = find(lag_y==1);
Ry_0 = ac_y(ind0);
Ry_1 = ac_y(ind1);

a1 = -Ry_1/Ry_0;
varX = Ry_0+a1*Ry_1;
% % Double check
% [a,e] = aryule(y,1);

[h_model,w_model]=freqz([1],[varX a1],512);

figure;
subplot(1,2,1)
plot(freq_y,pgm_y,'Color',"#D95319",'LineWidth',0.8)
hold on
plot(w/(2*pi),abs(h).^2,'Color',"#0072BD",'LineWidth',1)
plot(w_model/(2*pi),abs(h_model).^2,'Color',"#77AC30",'LineWidth',1)
xlim([0 0.5])
xlabel('Normalised frequency')
ylabel('PSD estimate')
title('periodogram of y')
grid on

subplot(1,2,2)
plot(freq_y,pgm_y,'Color',"#D95319",'LineWidth',0.8,'DisplayName','estimated PSD')
hold on
plot(w/(2*pi),abs(h).^2,'Color',"#0072BD",'LineWidth',1,'DisplayName','exact PSD')
plot(w_model/(2*pi),abs(h_model).^2,'Color',"#77AC30",'LineWidth',1,'DisplayName','model-based PSD')
xlim([0.4 0.5])
xlabel('Normalised frequency')
ylabel('PSD estimate')
title('zoomed in periodogram of y')
grid on
legend


%% Repeat for the sunspot time series
clear all
clc

load sunspot.dat
%%
%Obtaining the sequences
sun_orig = sunspot(:,2);
sun_zmean = detrend(sun_orig);
[pgm_orig, freq_orig]=pgm(sun_orig);
[pgm_zmean, freq_zmean]=pgm(sun_zmean);

order=[1 2 5 10 50];

% for original data
figure;
[a,e] = aryule(sun_orig, order(1));
[h_model,w_model]=freqz([1],a,512);

subplot(1,5,1)
plot(freq_orig,pgm_orig,'Color',"#0072BD",'Linewidth',0.7, 'DisplayName','estimated PSD');
hold on
plot(w_model/(2*pi),e*abs(h_model).^2,'Color',"#D95319",'LineWidth',1,'DisplayName','model-based PSD')
axis([0 0.5 0 250000])
xlabel('Normalised frequency')
ylabel('Magnitude')
title(['Model order ' num2str(order(1))])
legend
for i=2:length(order)
    [a,e] = aryule(sun_orig, order(i));
    [h_model,w_model]=freqz([1],a,512);

    subplot(1,5,i)
    plot(freq_orig,pgm_orig,'Color',"#0072BD",'Linewidth',0.7,'HandleVisibility','off');
    hold on
    plot(w_model/(2*pi),e*abs(h_model).^2,'Color',"#D95319",'LineWidth',1,'HandleVisibility','off')
    axis([0 0.5 0 250000])
    xlabel('Normalised frequency')
    ylabel('Magnitude')
    title(['Model order ' num2str(order(i))])
end

% for zero-mean data
figure;
[a,e] = aryule(sun_zmean, order(1));
[h_model,w_model]=freqz([1],a,512);

subplot(1,5,1)
plot(freq_zmean,pgm_zmean,'Color',"#0072BD",'Linewidth',0.7, 'DisplayName','estimated PSD');
hold on
plot(w_model/(2*pi),e*abs(h_model).^2,'Color',"#D95319",'LineWidth',1,'DisplayName','model-based PSD')
axis([0 0.5 0 70000])
xlabel('Normalised frequency')
ylabel('Magnitude')
title(['Model order ' num2str(order(1))])
legend
for i=2:length(order)
    [a,e] = aryule(sun_zmean, order(i));
    [h_model,w_model]=freqz([1],a,512);

    subplot(1,5,i)
    plot(freq_zmean,pgm_zmean,'Color',"#0072BD",'Linewidth',0.7,'HandleVisibility','off');
    hold on
    plot(w_model/(2*pi),e*abs(h_model).^2,'Color',"#D95319",'LineWidth',1,'HandleVisibility','off')
    axis([0 0.5 0 70000])
    xlabel('Normalised frequency')
    ylabel('Magnitude')
    title(['Model order ' num2str(order(i))])
end



