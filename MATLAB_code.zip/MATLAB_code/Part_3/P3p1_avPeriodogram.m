clc
clear
close all
%% Test pgm function
wgn128 = randn(1,128);
[periodogram128,freq_ax128] = pgm(wgn128);

wgn256 = randn(1,256);
[periodogram256,freq_ax256] = pgm(wgn256);

wgn512 = randn(1,512);
[periodogram512,freq_ax512] = pgm(wgn512);

figure;
subplot(1,3,1)
plot(freq_ax128,periodogram128,'Linewidth',1)
hold on
yline(1,'r','Linewidth',1);
xlabel('Normalised frequency')
ylabel('PSD estimate')
title('N = 128')

subplot(1,3,2)
plot(freq_ax256,periodogram256,'Linewidth',1)
hold on
yline(1,'r','Linewidth',1);
xlabel('Normalised frequency')
ylabel('PSD estimate')
title('N = 256')

subplot(1,3,3)
plot(freq_ax512,periodogram512,'Linewidth',1)
hold on
yline(1,'r','Linewidth',1);
xlabel('Normalised frequency')
ylabel('PSD estimate')
title('N = 512')

%% smooth the PSD estimate (periodogram)

h = 0.2*[1 1 1 1 1];

pgm_smooth128 = filter(h,[1],periodogram128);
pgm_smooth256 = filter(h,[1],periodogram256);
pgm_smooth512 = filter(h,[1],periodogram512);

figure;
subplot(1,3,1)
plot(freq_ax128,pgm_smooth128,'Linewidth',1)
hold on
yline(1,'r','Linewidth',1);
xlabel('Normalised frequency')
ylabel('Smoothed PSD estimate')
title('N = 128')

subplot(1,3,2)
plot(freq_ax256,pgm_smooth256,'Linewidth',1)
hold on
yline(1,'r','Linewidth',1);
xlabel('Normalised frequency')
ylabel('Smoothed PSD estimate')
title('N = 256')

subplot(1,3,3)
plot(freq_ax512,pgm_smooth512,'Linewidth',1)
hold on
yline(1,'r','Linewidth',1);
xlabel('Normalised frequency')
ylabel('Smoothed PSD estimate')
title('N = 512')


% To check for differnce or improvements, use the variance

pgm_var(1) = var(periodogram128);
pgm_var(2) = var(periodogram256);
pgm_var(3) = var(periodogram512);

pgm_smooth_var(1) = var(pgm_smooth128);
pgm_smooth_var(2) = var(pgm_smooth256);
pgm_smooth_var(3) = var(pgm_smooth512);

N = [128 256 512];
figure;
plot(N,pgm_var,'Linewidth',1,'DisplayName','orginial periodogram')
hold on
plot(N,pgm_smooth_var,'Linewidth',1,'DisplayName','smoothed periodogram')
grid on
title('Variances of the pgm')
xlabel('Sample size (N)')
ylabel('Variance of estimate')
legend

%% Calculate the PSD estimates for all eight segments and analyse their variation

wgn1024 = randn(1024,1);

figure;
for i=1:8
    wgn(i,:)=wgn1024(((i-1)*128+1):i*128);
    [periodogram(i,:),freq_ax(i,:)] = pgm(wgn(i,:));

    subplot(2,4,i)
    plot(freq_ax(i,:),periodogram(i,:),'Linewidth',1)
    hold on
    yline(1,'r','Linewidth',1);
    xlabel('Normalised frequency')
    ylabel('PSD estimate')
    title(['Segment ' num2str(i)])

    disp(['Segment ',num2str(i)])
    disp(['Variance: ', num2str(var(periodogram(i,:))),' ,   Mean: ', num2str(mean(periodogram(i,:)))])
end

% variance for each segment
pgm_var_seg = var(periodogram,0,2);
pgm_mean_seg = mean(periodogram,2);

%% averaged periodogram
periodogram_av = mean(periodogram,1);
pgm_av_var = var(periodogram_av);
disp(['Average periodogram Variance: ', num2str(pgm_av_var)])

figure;
plot(freq_ax(1,:),periodogram_av,'Linewidth',1)
hold on
yline(1,'r','Linewidth',1);
grid on
xlabel('Normalised frequency')
ylabel('PSD estimate')
title('Averaged Periodogram')





