function my_pdf(samples)
% Function to estimate the probability density function (pdf)
% Inputs:
% - samples: Collection of samples
% - bins: Number of bins for the histogram

% Check if the number of samples is at least 100
    if length(samples) < 100
        error('Number of samples should be at least 100.');
    end
    minval = floor(min(samples));
    maxval = ceil(max(samples));
    bins = minval:0.1:maxval;
    % Compute histogram
    [counts,centers] = hist(samples,bins);
    estimate = counts / (sum(counts) * 0.1);
    
    % Plot the estimated pdf
    bar(centers,estimate, 'hist');
    xlabel('Sample Values');
    ylabel('Probability Density');
    grid on;
end