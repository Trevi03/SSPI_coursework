clear all
clc

% Part 1
N = 10000;
v = randn(1,N);
figure;
histogram(v,'Normalization','pdf','BinWidth',0.1);
title(['PDF estimate for N=',num2str(N)])
xlabel('Observation')
ylabel('Probability density')

figure;
my_pdf(v)
%%
% Part 2
% Theoretical dist
pd1 = makedist('Uniform','lower',-1,'upper',2);
f = -2:.001:3;
pdf1 = pdf(pd1,f);

N = 10.^[2 3 4];
count = 1;

figure;
for n=N
    v3 = rp3(1,n);
    subplot(1,3,count);
    my_pdf(v3)
    hold on
    plot(f,pdf1,'r','LineWidth',1.3);
    title(['PDF estimate for N=',num2str(n)]);
    xlabel('Observation')
    ylabel('Probability Density')
    xlim([-1.5 2.5])
    count = count +1;
end
legend({'Sample pdf','Theoretical pdf'})
