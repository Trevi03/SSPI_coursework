clear all
clc
close all

%% Wiener filter
x = randn(1000,1); %Input

% Creating the 'unknown system'
b = [1,2,3,2,1];
a = [1];
y_orig = filter(b,a,x); %Output

std_y_orig = std(y_orig); % std of y_orig
y = (y_orig-mean(y_orig))./std_y_orig; % standardised y (unit std and zmean)

% figure;
% plot(y,'Linewidth',1)
% ylabel('Magnitude');
% xlabel('Time')
% title('Normalised filter output');

%Generating WGN eta
eta = (0.1).*randn(1000,1);

% add to y
z = eta+y;
% var_z = var(z);

figure;
plot(y,'Linewidth',1)
ylabel('Magnitude');
xlabel('Time')
title('Normalised filter output');

r = snr(y,eta);
disp(['Signal-to- Noise Ratio (SNR): ',num2str(r)])

%% Calculate the statistics

%Calculating rxx
Nw = 4; %length of weiner filter
rxx = xcorr(x,Nw,'unbiased');
rxx = rxx(ceil(length(rxx)/2):length(rxx));

%Constructing Matrix Rxx
for i=1:(Nw+1)
    for j=1:(Nw+1)
        Rxx(i,j)=rxx(abs(j-i)+1); 
    end
end

% Calculate pzx
pzx = xcorr(x,z,Nw,'unbiased');
pzx = pzx(ceil(length(pzx)/2):-1:1);

w_opt = (inv(Rxx))*pzx.*std_y_orig; % non-normalised
disp(['w opt: ',num2str(w_opt')])

%% Varying the scaling applied to the additive noise
var = [0.1 0.5 1 3 6 10];

for v=1:6
    eta2=[];
    z2=[];
    
    eta2 = sqrt(var(v)).*randn(1000,1);
    z2= y + eta2;
    
    %Obtaining SNR values (in dB)
    SNR(v) = snr(y,eta2);
    
    %Obtaining Wiener filter solution
    pzx = xcorr(x,z2,Nw,'unbiased');
    pzx = pzx(ceil(length(pzx)/2):-1:1);
    
    W_opt(v,:) = ((inv(Rxx))*pzx).*std_y_orig;

    disp(['variance = ',num2str(var(v)),', w_opt: ',num2str(W_opt(v,:)),' , SNR: ',num2str(SNR(v))])
end

%% For Nw > 4

Nw = 5;
%Constructing Matrix Rxx
rxx5 = xcorr(x,Nw,'unbiased');
rxx5 = rxx5(ceil(length(rxx5)/2):length(rxx5));
for i=1:(Nw+1)
    for j=1:(Nw+1)
        Rxx5(i,j)=rxx5(abs(j-i)+1); 
    end
end

% Calculate pzx
pzx5 = xcorr(x,z,Nw,'unbiased');
pzx5 = pzx5(ceil(length(pzx5)/2):-1:1);

W_opt5 = ((inv(Rxx5))*pzx5).*std_y_orig; % non-normalised

disp(['Nw = ',num2str(Nw),', w_opt: ',num2str(W_opt5')])


Nw = 6;
%Constructing Matrix Rxx
rxx6 = xcorr(x,Nw,'unbiased');
rxx6 = rxx6(ceil(length(rxx6)/2):length(rxx6));
for i=1:(Nw+1)
    for j=1:(Nw+1)
        Rxx6(i,j)=rxx6(abs(j-i)+1); 
    end
end

% Calculate pzx
pzx6 = xcorr(x,z,Nw,'unbiased');
pzx6 = pzx6(ceil(length(pzx6)/2):-1:1);

W_opt6 = ((inv(Rxx6))*pzx6).*std_y_orig; % non-normalised
disp(['Nw = ',num2str(Nw),', w_opt: ',num2str(W_opt6')])


Nw = 7;
%Constructing Matrix Rxx
rxx7 = xcorr(x,Nw,'unbiased');
rxx7 = rxx7(ceil(length(rxx7)/2):length(rxx7));
for i=1:(Nw+1)
    for j=1:(Nw+1)
        Rxx7(i,j)=rxx7(abs(j-i)+1); 
    end
end

% Calculate pzx
pzx7 = xcorr(x,z,Nw,'unbiased');
pzx7 = pzx7(ceil(length(pzx7)/2):-1:1);

W_opt7 = ((inv(Rxx7))*pzx7).*std_y_orig; % non-normalised

disp(['Nw = ',num2str(Nw),', w_opt: ',num2str(W_opt7')])


%% The least mean square (LMS) algorithm

N_w = 4;
filt_order = N_w+1;

%Finding critical mu for convergence
lamda = eig(Rxx);
lamda_max = max(lamda);   %Finds maximum eigenvalue
mu_crit1 = 2/(lamda_max); %Convergence in the mean
mu_crit2 = 2/trace(Rxx);  %Mean square convergence

% Choosing a mu value < mu_crit and > zero
% The higher the mu the faster the convergence 
mu=0.004;
[y_hat, error, evol_weights] = lms(x,z,mu,filt_order);
evol_weights = evol_weights.*std_y_orig;

%Visualising results
n=[0:length(x)-1];

figure;
subplot(1,2,1)
plot(n,z,'Color',"#0072BD",'Linewidth',1, 'DisplayName','True Output')
hold on
plot(n,y_hat,'Color',"#D95319",'Linewidth',1, 'DisplayName','Estimated Output');
title('System output') ;
xlabel('Samples')
ylabel('Magnitude')
legend
grid on

subplot(1,2,2)
plot(b,'o','Color',"#0072BD",'Linewidth',1.3,DisplayName='Actual weights')
hold on
iteration = size(evol_weights);
iteration = iteration (2);
plot(evol_weights(:,iteration), '*','Color',"#D95319",'Linewidth',1.3,DisplayName='Estimated weights')
legend
title('Comparison of the actual weights and the estimated weights') ;
ylim([0 3.5])
grid on

%% adaptation gain μ to be 0.01
N_w = 4;
filt_order = N_w+1;
mu = 0.01;

[y_hat, error, evol_weights] = lms(x,z,mu,filt_order);
evol_weights = evol_weights.*std_y_orig; 
n=[0:length(x)-1];


figure;
subplot(1,2,1)
Sz = size(evol_weights,1);

for i=1:Sz
    plot(evol_weights(i,:),'Linewidth',1.3,'DisplayName',['w_{opt}[',num2str(i),']'])
    hold on
end
xlabel('Sample')
ylabel('Magnitude')
title('Time evolution of the coefficients, \mu=0.01')
legend
grid on

subplot(1,2,2)
plot(error.^2) ;
title('Corresponding evolution of squared error') ;
xlabel('Samples')
ylabel('Squared error estimate')
grid on

%%
N_w = 4;
filt_order = N_w+1;
MU = [0.002 0.02 0.1 0.4];
n=[0:length(x)-1];

figure;

for j=1:length(MU)
    [y_hat, error, evol_weights] = lms(x,z,MU(j),filt_order);
    evol_weights = evol_weights.*std_y_orig; 
    Sz = size(evol_weights,1);
    subplot(1,4,j)
    for i=1:Sz
        plot(evol_weights(i,:),'Linewidth',1.3,'DisplayName',['w_{opt}[',num2str(i),']'])
        hold on
    end
    xlabel('Sample')
    ylabel('Magnitude')
    title(['Time evolution, \mu=',num2str(MU(j))])
    grid on
end

