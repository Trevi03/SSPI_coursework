function [y_hat, error, evol_weights] = lms(x_input,z_input,mu_adaptgain,filter_order,mode, system_coeff, std_y)
% The least mean square (LMS) algorithm with optional gear shift
%   Inputs:  x_input,z_input = N -sample vectors x and z 
%            mu_adaptgain = the adaptation gain 
%            filter_order = order of the adaptive filter (Nw+1) 
%   Outputs: y_hat = the LMS estimate 
%            error = output the error vector e[n] 
%            evol_weights = evolution of the adaptive weights in time, (Nw + 1) × N matrix
    
    arguments
        x_input {mustBeVector}
        z_input {mustBeVector,mustBeEqualSize(x_input,z_input)}
        mu_adaptgain (1,1) {mustBeNumeric}
        filter_order (1,1) {mustBeInteger}
        mode (1,:) char {mustBeMember(mode,{'default','gearshift'})} = 'default'
        system_coeff (1,:) {mustBeVector} = [0]
        std_y (1,1) {mustBeNumeric} = 1
    end

    N = length(x_input); % length(x)=length(z)
    w = zeros(filter_order,1); % weights
    y_hat = [];
    error = [];
    
    if isequal(mode,'gearshift')
        input_var = var(x_input);
        % upper bound 
        gain_max = 1/(input_var*filter_order); 
        % lower bound 
        gain_min = 0.01;

        evol_weights = zeros(filter_order,N-filter_order);
        
        adapt_gain(filter_order)=mu_adaptgain;
        alpha = 0.99;
        beta = 0.001;
    end

    ind=1;
    for n = filter_order : N 
        x_n = x_input(n:-1:(n-filter_order+1));
        y_hat(n)= w' * x_n;
        error(n) = z_input(n) - y_hat(n) ; % e[n] = z[n] − y_hat[n]
        
        if isequal(mode,'default')
            w = w + mu_adaptgain * x_n * error(n);
        end

        if isequal(mode,'gearshift')
            w = w + adapt_gain(n) * x_n * error(n) ;
            adapt_gain(n+1) = alpha*adapt_gain(n) + beta*(error(n)^2);
            
            % Checking the constraints of mu 
            if (adapt_gain(n+1)>gain_max)
                adapt_gain(n+1)= gain_max;%max
            elseif(adapt_gain(n+1)<gain_min)
                adapt_gain(n+1)= gain_min;
            else
                adapt_gain(n+1) = adapt_gain(n+1) ;
            end
            
            for i=1:filter_order % 20% overshoot
                if w(i)>1.2*(system_coeff(i)/std_y)
                    w(i)=1.2*(system_coeff(i)/std_y);
                end
            end
        end

        evol_weights(:,ind) = w;
        ind=ind+1;
    end 
end

% Custom validation function
function mustBeEqualSize(a,b)
    % Test for equal size
    if ~isequal(size(a),size(b))
        eid = 'Size:notEqual';
        msg = 'Size of first input must equal size of second input.';
        error(eid,msg)
    end
end