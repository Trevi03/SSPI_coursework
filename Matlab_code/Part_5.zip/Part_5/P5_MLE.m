clear all
clc
close all

%%
x = zeros(1,10); %N=10
n=1:10;

ind = 1;
figure;
for f0 = [0.05 0.1 0.25 0.4 0.45]
    x = cos((2*pi*f0).*(n-1));
    [pgm_x fx]= periodogram(x);
    fx = fx./(2*pi); %normalised frequency
    [~,max_locs] = max(pgm_x); % find the maximum point
    mle = fx(max_locs);

    subplot(1,5,ind)
    plot(fx,pgm_x,'Linewidth',1,'DisplayName','pgm');
    hold on
    xline(mle,'r--','LineWidth',0.7,'DisplayName','mle');
    title(['f_0 = ',num2str(f0)]);
    ylabel('Magnitude')
    xlabel('Normalised Frequency')
    xlim([0 0.5])
    grid on
    ind=ind+1;
end
legend










