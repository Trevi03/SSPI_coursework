clear all
clc

M = 100;  % members of an ensemble
N = 100;  % length
v1 = rp1(M,N);
v2 = rp2(M,N);
v3 = rp3(M,N);

% Compute the ensemble mean and standard deviation
m1 = mean(v1);
m2 = mean(v2);
m3 = mean(v3);
sd1 = std(v1);
sd2 = std(v2);
sd3 = std(v3);

% plot mean as function of time
figure;
time = 1:N;

subplot(3,1,1)
plot(time,m1)
title('rp1')
xlabel('time')
ylabel('ensemble mean')
ylim([0 2])

subplot(3,1,2)
plot(time,m2)
title('rp2')
xlabel('time')
ylabel('ensemble mean')
ylim([0 2])

subplot(3,1,3)
plot(time,m3)
title('rp3')
xlabel('time')
ylabel('ensemble mean')
ylim([0 2])

% plot sd as function of time
figure;
time = 1:N;

subplot(3,1,1)
plot(time,sd1)
title('rp1')
xlabel('time')
ylabel('ensemble SD')
ylim([0 1.5])

subplot(3,1,2)
plot(time,sd2)
title('rp2')
xlabel('time')
ylabel('ensemble SD')
ylim([0 1.5])

subplot(3,1,3)
plot(time,sd3)
title('rp3')
xlabel('time')
ylabel('ensemble SD')
ylim([0 1.5])
% Comment on the stationarity of each process.


%%

M = 4;     % members of an ensemble
N = 1000;  % length
v1 = rp1(M,N);
v2 = rp2(M,N);
v3 = rp3(M,N);

% Compute the ensemble mean and standard deviation
m1 = mean(v1,2);
m2 = mean(v2,2);
m3 = mean(v3,2);
sd1 = std(v1,0,2);
sd2 = std(v2,0,2);
sd3 = std(v3,0,2);

% display the values
disp('mean per realisation:')
fprintf('rp1: ');disp(m1')
fprintf('rp2: ');disp(m2')
fprintf('rp3: ');disp(m3')

disp('std per realisation:')
fprintf('rp1: ');disp(sd1')
fprintf('rp2: ');disp(sd2')
fprintf('rp3: ');disp(sd3')

% Comment on the ergodicity of each process

