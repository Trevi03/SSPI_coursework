clear all
clc

x = rand(1,1000)';
rng(42);

%% Plot the results
% figure;
% plot(x);

% Q1.1
m = (1+0)/2;
m_hat = mean(x);

disp(['Theoretical mean, m = E{X} = ',num2str(m)])
disp(['sample mean, m_hat = ', num2str(m_hat)])
% Comment on the accuracy of the sample mean as an estimator

% Q1.2
sd = sqrt((1+0)^2/12);
sd_hat = std(x);

disp(['Theoretical value of std, s = ',num2str(sd)])
disp(['sample standard deviation, s_hat = ', num2str(sd_hat)])
% Comment on the accuracy of s


% Q1.3
y = rand(100,1000)';
u_hat = mean(y);
s_hat = std(y);

figure;
plot(u_hat,s_hat,'o','LineWidth',1);
hold on;
plot(m,sd,'rx','LineWidth',1);
title('Plot of estimated means and standard deviations')
xlabel('Mean')
ylabel('Standard Deviation')
legend({'estimated', 'theoretical'})
axis([0.47 0.53 0.275 0.305])
% Comment on their bias, by showing how they cluster about their theoretical values.

%% Theoretical pdf for uniform distribution
pd1 = makedist('Uniform');
f = -0.5:.001:1.5;
pdf1 = pdf(pd1,f);
figure;
plot(f,pdf1,'r','LineWidth',1); 
axis([-0.5 1.5 0 1.2])
title('Theoretical PDF')
xlabel('Observation')
ylabel('Probability Density')
%%
% Q1.4
figure;
subplot(1,3,1)
histogram(x,'Normalization','pdf');
hold on
plot(f,pdf1,'r','LineWidth',1,'HandleVisibility','off'); 
xlim([-0.5 1.5])
title('PDF estimate for N=1000')
xlabel('Observation')
ylabel('Probability density')

subplot(1,3,2)
histogram(x,'Normalization','pdf','NumBins',40);
hold on
plot(f,pdf1,'r','LineWidth',1,'HandleVisibility','off'); 
xlim([-0.5 1.5])
title('PDF estimate for N=1000')
xlabel('Observation')
ylabel('Probability density')

subplot(1,3,3)
z = rand(1,100000);
histogram(z,'Normalization','pdf','DisplayName','Sample pdf');
hold on
plot(f,pdf1,'r','LineWidth',1,'DisplayName','Theoretical pdf'); 
xlim([-0.5 1.5]);
title("PDF estimate for N=100000")
xlabel('Observation')
ylabel('Probability density')
legend


%%  Q1.5 redo 1-4 with gaussian random variable, zero mean, unit sd
numSamples = 1000;
mu = 0;
sigma = 1;
x1 = mu + sigma.*randn(numSamples, 1);

% % Plot the distribution
% figure;histogram(x1(:));

% Q1.1
m1 = 0;
m1_hat = mean(x1);

disp('\n repeat:')
disp(['Theoretical mean, m = E{X} = ',num2str(m1)])
disp(['sample mean, m_hat = ', num2str(m1_hat)])
% Comment on the accuracy of the sample mean as an estimator

% Q1.2
sd1 = 1;
sd1_hat = std(x1);

disp(['Theoretical value of std, s = ',num2str(sd1)])
disp(['sample standard deviation, s_hat = ', num2str(sd1_hat)])
% Comment on the accuracy of s

%% Theoretical pdf for gaussian distribution

f1 = -4:0.01:4;
pdf2 = normpdf(f1,mu,sigma);
figure;
plot(f1,pdf2,'r','LineWidth',1); 
ylim([0 0.45])
xlabel('Observation')
ylabel('Probability Density')

%%
% Q1.3
y1 = sigma.*randn(numSamples, 10);
u1_hat = mean(y1);
s1_hat = std(y1);

figure;
plot(u1_hat,s1_hat,'o','LineWidth',1);
hold on;
plot(m1,sd1,'rx','LineWidth',1);
title('Plot of estimated means and standard deviations')
xlabel('Mean')
ylabel('Standard Deviation')
legend({'estimated', 'theoretical'})
axis([-0.07 0.07 0.95 1.05])
% Comment on their bias, by showing how they cluster about their theoretical values.
%%
figure;
subplot(1,3,1)
histogram(y1,'Normalization','pdf');
hold on
plot(f1,pdf2,'r','LineWidth',1); 
xlim([-4 4])
title("PDF estimate for N=1000")
xlabel('Observation')
ylabel('Probability Density')

subplot(1,3,2)
histogram(y1,'Normalization','pdf','NumBins',100);
hold on
plot(f1,pdf2,'r','LineWidth',1); 
xlim([-4 4])
title("PDF estimate for N=1000")
xlabel('Observation')
ylabel('Probability Density')

% Q1.4
subplot(1,3,3)
z1 = sigma.*randn(numSamples, 100);
histogram(z1,'Normalization','pdf','DisplayName','Sample pdf');
hold on
plot(f1,pdf2,'r','LineWidth',1,'DisplayName','Theoretical pdf'); 
xlim([-4 4])
title("PDF estimate for N=100,000")
xlabel('Observation')
ylabel('Probability Density')
legend
