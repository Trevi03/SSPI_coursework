clear all
clc
close all

%%
[A,~] = audioread('A.m4a');
[E,~] = audioread('E.m4a');
[S,~] = audioread('S.m4a');
[T,~] = audioread('T.m4a');
[X,fs] = audioread('X.m4a');

%%
N = 1000; %samples
voice_rec = zeros(5,N);
letters = ['A','E','S','T','X'];
voice_rec(1,:)= A(26000:26000+N-1);
voice_rec(2,:)= E(24900:24900+N-1);
voice_rec(3,:)= S(28000:28000+N-1);
voice_rec(4,:)= T(28500:28500+N-1);
voice_rec(5,:)= X(19400:19400+N-1);
%%
MU = [0.01,0.05,0.1,0.2,0.4];


order=[1:70];
figure;
for s = 1:length(letters) % for each letter
    for m = 1:length(MU) % for each mu
        for p = order % model order p
            mu = MU(m);
            [y, error, ~] = adaptive_lms(voice_rec(s,:)',mu,p);
            % use Sum of Squared Errors to test predictor accuracy
            SSE(m,p) = sum(error.^2);
            
            var_in = var(voice_rec(s,:));
            var_error = var(error);
        end
        subplot(1,5,s)
        hold on
        plot(order,SSE(m,:),'Linewidth',1,'DisplayName',['\mu=',num2str(mu)])
        grid on
    end
    title(['Sound ',letters(s)]);
    ylabel('SSE');
    xlabel('Model Order');
    xlim([1 max(order)])
end
legend

%% repeat same thing for gear shift

mu = 0.1;
figure;
for s = 1:length(letters) % for each letter
    for p = order % model order p
        [y, error, ~] = adaptive_lms(voice_rec(s,:)',mu,p,"gearshift");
        % use Sum of Squared Errors to test predictor accuracy
        SSE(m,p) = sum(error.^2);
        
        var_in = var(voice_rec(s,:));
        var_error = var(error);
        % Pred_gain_16(m,p) = 10*log10(var_in/var_error);
    end
    hold on
    plot(order,SSE(m,:),'Linewidth',1,'DisplayName',letters(s))
    grid on
end
title('Using gear shifting');
ylabel('SSE');
xlabel('Model Order');
xlim([1 max(order)])
legend


%% prediction gains of the corresponding predictors

[A16,~] = audioread('A.wav');
[E16,~] = audioread('E.wav');
[S16,~] = audioread('S.wav');
[T16,~] = audioread('T.wav');
[X16,fs] = audioread('X.wav');

N = 1000; %samples
voice_rec16 = zeros(5,N);
voice_rec16(1,:)= A(9900:9900+N-1);
voice_rec16(2,:)= E(9800:9800+N-1);
voice_rec16(3,:)= S(10000:10000+N-1);
voice_rec16(4,:)= T(11200:11200+N-1);
voice_rec16(5,:)= X(7600:7600+N-1);
%%
mu=0.1;
ind=1;
figure;
for s=1:length(letters) %Iterations for the sounds of the 5 letters
    for p=1:50 %Iterations for the different AR model orders
        [y, error, ~] = adaptive_lms(voice_rec(s,:)',mu,p);
        [y_16, error_16, ~] = adaptive_lms(voice_rec16(s,:)',mu,p);
        
        %For 44.1 kHz
        var_in = var(voice_rec(s,:));
        var_error = var(error);
        Pred_gain(s,p) = 10*log10(var_in/var_error);
        
        %For 16kHz
        var_in_16 = var(voice_rec16(s,:));
        var_error_16 = var(error_16);
        Pred_gain_16(s,p) = 10*log10(var_in_16/var_error_16);
    end
    
    subplot(1,5,ind)
    hold on
    plot(order,Pred_gain(s,:),'Linewidth',1,DisplayName='fs=44.1kHz')
    plot(order,Pred_gain_16(s,:),'Linewidth',1,DisplayName='fs=16kHz')
    title(['Letter ' letters(s)]);
    ylabel('Prediction Gain R_p');
    xlabel('Model Order');
    xlim([1 50])
    grid on
    
    ind=ind+1;
end
legend

