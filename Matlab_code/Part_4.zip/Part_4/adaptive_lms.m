function [x_hat, error, evol_weights] = adaptive_lms(x_input,mu_adaptgain,filter_order,mode)
% The Adaptive least mean square (LMS) algorithm with optional gear shift    
    arguments
        x_input {mustBeVector}
        mu_adaptgain (1,1) {mustBeNumeric}
        filter_order (1,1) {mustBeInteger}
        mode (1,:) char {mustBeMember(mode,{'default','gearshift'})} = 'default'
    end

    N=length(x_input);
    x_hat = [];
    error=[];
    w = zeros(filter_order,1);

    if isequal(mode,'gearshift')
        input_var = var(x_input);
        % upper bound 
        gain_max = 1/(input_var*filter_order); 
        % lower bound 
        gain_min = 0.01;

        evol_weights = zeros(filter_order,N-filter_order);
        
        adapt_gain(filter_order+1)=mu_adaptgain;
        alpha = 0.99;
        beta = 0.001;
    end

    index=1;
    for n = filter_order+1 : N
        x_n = x_input(n-1:-1:n-filter_order);
        x_hat(n) = w'* x_n;
        error(n) = x_input(n) - x_hat(n);

        if isequal(mode,'default')
            w = w + mu_adaptgain * x_n * error(n);
        end

        if isequal(mode,'gearshift')
            w = w + adapt_gain(n) * x_n * error(n) ;
            adapt_gain(n+1) = alpha*adapt_gain(n) + beta*(error(n)^2);
            
            % Checking the constraints of mu 
            if (adapt_gain(n+1)>gain_max)
                adapt_gain(n+1)= gain_max;
            elseif(adapt_gain(n+1)<gain_min)
                adapt_gain(n+1)= gain_min;
            else
                adapt_gain(n+1) = adapt_gain(n+1) ;
            end
        end
        evol_weights(:,index) = w;
        index = index+1;
    end 
end