clear all
clc
close all

%% Initialise the signals from 4.4
eta = randn(1000,1);
a = [1 0.9 0.2];
b = [1];
x = filter(b,a,eta); 

%% Initialise the speech sample
[E,fs] = audioread('E.m4a');
N = 1000; %samples
voice_rec= E(26000:26000+N-1);

%% For the signals from 4.4

mu = 0.1;
filter_order = 2;

% the sign LMS algorithms
[x_hat_SE, error_SE,evol_weights_SE] = signed_error(x,mu,filter_order);
[x_hat_SR, error_SR,evol_weights_SR] = signed_regressor(x,mu,filter_order);
[x_hat_SS, error_SS,evol_weights_SS] = sign_sign(x,mu,filter_order);

% basic adaptive LMS algorithm
[x_hat, error, evol_weights] = adaptive_lms(x,mu,filter_order);

%%
figure;
hold on
plot(evol_weights(1,:),'r','Linewidth',1.3,'DisplayName','basic LMS')
plot(evol_weights_SE(1,:),'g','Linewidth',1.3,'DisplayName','signed−error')
plot(evol_weights_SR(1,:),'b','Linewidth',1.3,'DisplayName','signed−regressor')
plot(evol_weights_SS(1,:),'m','Linewidth',1.3,'DisplayName','sign−sign')

plot(evol_weights(2,:),'r','Linewidth',1.3,'HandleVisibility','off')
plot(evol_weights_SE(2,:),'g','Linewidth',1.3,'HandleVisibility','off')
plot(evol_weights_SR(2,:),'b','Linewidth',1.3,'HandleVisibility','off')
plot(evol_weights_SS(2,:),'m','Linewidth',1.3,'HandleVisibility','off')

yline(-0.2,'k--','DisplayName','Actual \alpha values');
yline(-0.9,'k--',HandleVisibility='off');
xlabel('Sample')
ylabel('Magnitude')
title('Time evolution of Coefficients')
legend
grid on

%% For the the sound of letter e

mu = 0.01;
p = 6;

[y_SE, error_ySE,evol_weights_ySE] = signed_error(voice_rec,mu,p);
[y_SR, error_ySR,evol_weights_ySR] = signed_regressor(voice_rec,mu,p);
[y_SS, error_ySS,evol_weights_ySS] = sign_sign(voice_rec,mu,p);
[y, error_y, evol_weights_y] = adaptive_lms(voice_rec,mu,p);

%%

figure;
hold on
plot(evol_weights_y(1,:),'r','Linewidth',1.3,'DisplayName','basic LMS')
plot(evol_weights_ySE(1,:),'g','Linewidth',1.3,'DisplayName','signed−error')
plot(evol_weights_ySR(1,:),'b','Linewidth',1.3,'DisplayName','signed−regressor')
plot(evol_weights_ySS(1,:),'m','Linewidth',1.3,'DisplayName','sign−sign')
xlabel('Sample')
ylabel('Magnitude')
title('Time evolution of the first coefficient')
legend
grid on





%% Functions for the sign LMS algorithms

function [x_hat, error,evol_weights] = signed_error(x_input,mu_adaptgain,filter_order)
    
    N=length(x_input); %Assuming that length of x is equal to length of z
    w = zeros(filter_order,1);
    
    ind=1;
    for n = filter_order+1 : N
        x_n = x_input(n-1:-1:n-filter_order);
        x_hat(n) = w'* x_n;
        error(n) = x_input(n) - x_hat(n) ;

        w = w + mu_adaptgain * x_n * sign(error(n));
        evol_weights(:,ind)=w;
        ind=ind+1;
    end 
end

function [x_hat, error,evol_weights] = signed_regressor(x_input,mu_adaptgain,filter_order)
    
    N=length(x_input); %Assuming that length of x is equal to length of z
    w = zeros(filter_order,1);
    
    ind=1;
    for n = filter_order+1 : N
        x_n = x_input(n-1:-1:n-filter_order);
        x_hat(n) = w'* x_n;
        error(n) = x_input(n) - x_hat(n) ;

        w = w + mu_adaptgain * sign(x_n) * error(n);
        evol_weights(:,ind)=w;
        ind=ind+1;
    end 
end

function [x_hat, error,evol_weights] = sign_sign(x_input,adaptmu_adaptgain_gain,filter_order)
    
    N=length(x_input); %Assuming that length of x is equal to length of z
    w = zeros(filter_order,1);
    
    ind=1;
    for n = filter_order+1 : N
        x_n = x_input(n-1:-1:n-filter_order);
        x_hat(n) = w'* x_n;
        error(n) = x_input(n) - x_hat(n) ;

        w = w + adaptmu_adaptgain_gain * sign(x_n) * sign(error(n));
        evol_weights(:,ind)=w;
        ind=ind+1;
    end 
end