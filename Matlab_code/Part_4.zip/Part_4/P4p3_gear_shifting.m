clear all
clc
close all
%% Initialise the signals

x = randn(1000,1); %Input

% Creating the 'unknown system'
b = [1,2,3,2,1];
a = [1];
y_orig = filter(b,a,x); %Output
std_y_orig = std(y_orig);
y = (y_orig-mean(y_orig))./std_y_orig; % standardised y (unit std and zmean)

eta = (0.1).*randn(1000,1);
z = eta+y;

%% implement a time-varying adaptation gain
N_w = 4;
filt_order=N_w+1;

[y_gs, error, evol_weights] = lms(x,z,0.05,filt_order,"gearshift",b,std_y_orig);
evol_weights = evol_weights.*std_y_orig;

%Comparing with Original Method
[y_hat, error_orig,evol_weights_orig] = lms(x,z,0.01,filt_order);
evol_weights_orig = evol_weights_orig.*std_y_orig;

%%
figure;
subplot(1,3,1)
Sz = size(evol_weights_orig,1);

for i=1:Sz
    plot(evol_weights_orig(i,:),'Linewidth',1.3,'DisplayName',['w_{opt}[',num2str(i),']'])
    hold on
end
xlabel('Sample')
ylabel('Magnitude')
title('Coefficients, Orig method')
legend
grid on

subplot(1,3,2)
Sz = size(evol_weights,1);

for i=1:Sz
    plot(evol_weights(i,:),'Linewidth',1.3,'DisplayName',['w_{opt}[',num2str(i),']'])
    hold on
end
xlabel('Sample')
ylabel('Magnitude')
title('Coefficients, with gearshift')
grid on

subplot(1,3,3)
plot(error_orig.^2,'Color',"#0072BD",'Linewidth',1, 'DisplayName','Original');
hold on
plot(error.^2,'Color',"#D95319",'Linewidth',1, 'DisplayName','Gearshift');
title('Corresponding evolution of squared error') ;
xlabel('Samples')
ylabel('Squared error estimate')
grid on
legend

%% rise time between two methods

time_ax = [1:length(evol_weights(1,:))];
for i=1:filt_order

    [~, lower_gs] = find(evol_weights(i,:) > 0.1*b(i), 1);
    [~, lower_orig] = find(evol_weights_orig(i,:) > 0.1*b(i), 1);

    t1_gs = time_ax(lower_gs);
    t1_orig = time_ax(lower_orig);

    [~, upper_gs] = find(evol_weights(i,:) > 0.9*b(i), 1);
    [~, upper_orig] = find(evol_weights_orig(i,:) > 0.9*b(i), 1);

    t2_orig= time_ax(upper_orig);
    t2_gs = time_ax(upper_gs);
    
    RT_orig(i) = t2_orig - t1_orig;
    RT_gs(i) = t2_gs-t1_gs;
end

rt_orig = mean(RT_orig);
rt_gs = mean(RT_gs);
disp(['Rise time for original lms: ',num2str(rt_orig)])
disp(['Rise time for gearshift lms: ',num2str(rt_gs)])
