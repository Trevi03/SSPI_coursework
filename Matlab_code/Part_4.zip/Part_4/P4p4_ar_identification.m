clear all
clc
close all

%% Initialise the signals 

eta = randn(1000,1); %This is already standardised

%Constructing AR model
a = [1 0.9 0.2];
b = [1];
x = filter(b,a,eta); %Output of filter

%% Structure implementation
mu = 0.01;
[x_hat, error, evol_weights] = adaptive_lms(x,mu,2);

Sz = size(evol_weights,1);
figure;
for i=1:Sz
    plot(evol_weights(i,:),'Linewidth',1.3,'DisplayName',['a',num2str(i)])
    hold on
end
yline(-0.2,'k--','DisplayName','Actual a values');
yline(-0.9,'k--',HandleVisibility='off');
xlabel('Sample')
ylabel('Magnitude')
title('Time evolution of Coefficients')
legend
grid on


%% For different gains

mu = [0.01 0.05 0.1 0.5];
figure;
for j=1:length(mu)
    [x_hat, error, evol_weights] = adaptive_lms(x,mu(j),2);
    
    Sz = size(evol_weights,1);
    subplot(2,2,j);
    for i=1:Sz
        plot(evol_weights(i,:),'Linewidth',1.3,'DisplayName',['a',num2str(i)])
        hold on
    end
    yline(-0.2,'k--',HandleVisibility='off');
    yline(-0.9,'k--',HandleVisibility='off');
    xlabel('Sample')
    ylabel('Magnitude')
    title(['Time evolution, \mu=',num2str(mu(j))])
    grid on
end
legend

