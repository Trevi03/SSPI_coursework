clear
clc
close all

%% Stability of coefficients
N=100;
a1 = 5.*rand(N,1)-2.5;
a2 = 3.*rand(N,1)-1.5;
x = randn(1,N);

stable = [];

for i =1:N
    if(a1(i)+a2(i)<1) && (a2(i)-a1(i)<1) && (a2(i)>-1) && (a2(i)<1)
        stable = [stable [a1(i);a2(i)]]; % Concatenate the end of the vector with new values.
    end
end

figure;
plot(stable(1,:),stable(2,:),'*','DisplayName','Stable pairs');
hold on
grid on

legend
xlabel('a1');
ylabel('a2');
title('Stable and unstable coefficients for N = 10000');
% Give theoretical proofs of this observation
%Plotting the Stability Triangle
%For line between real and complex roots
x1=[-2:0.01:2];
plot(x1,-((x1).^2)/4,'--k','Linewidth',1,"HandleVisibility","off")
plot([-2 2],[-1 -1],'k','Linewidth',1,"HandleVisibility","off")
plot([-2 0],[-1 1],'k','Linewidth',1,"HandleVisibility","off")
plot([0 2],[1 -1],'k','Linewidth',1,'DisplayName','Stability Triangle')


%% Sunspot modelling
load sunspot.dat
sun=sunspot(:, 2);
sun_zmean= detrend(sun);

i=1;
figure;
for n=[5,20,250]
    orig = sun(1:n);
    zmean = sun_zmean(1:n);
    subplot(1,3,i)
    [a,b] = xcorr(orig,'unbiased');
    [c,d] = xcorr(zmean,'unbiased');

    plot(b,a,'DisplayName','Original','Color',"#0072BD")
    hold on
    plot(d,c,'DisplayName','zero-mean','Color',"#D95319")
    grid on
    xlabel('\tau (year lag)');
    ylabel('signal amplitude')
    title(['ACF of Sunspot Data for N=' num2str(n)]);
    i=i+1;
end
legend

%% Yule-Walker equations
load sunspot.dat
sun=sunspot(:, 2);
sun_zmean= zscore(sun);

[xc,lags] = xcorr(sun_zmean,50,'coeff');

figure;
stem(lags(51:end),xc(51:end),'filled')
xlabel('Lag (\tau)')
ylabel('ACF')
title('Autocorrelation Function of standardised sunspot data')
grid
%% PACF
% For original data
[arcoefs,E,K] = aryule(sun,10);
pacf = -K;
conf95 = sqrt(2)*erfinv(0.95)/sqrt(288);
conf99 = sqrt(2)*erfinv(0.99)/sqrt(288);

figure;
subplot(1,2,1)
stem(pacf,'filled','HandleVisibility','off',LineWidth=0.7)
xlabel('Time lag (\tau)')
ylabel('Partial ACF (correlation)')
title('PACF on original time series');
xlim([0 10])
hold on
plot(xlim,[1 1]'*[-conf95 conf95],'r--','HandleVisibility','off')
plot(xlim,[1 1]'*[-conf99 conf99],'g--','HandleVisibility','off')
hold off
grid on

% For zero-mean data
[arcoefs,E,K] = aryule(sun_zmean,10);
pacf = -K;
subplot(1,2,2)
stem(pacf,'filled','DisplayName','PACF',LineWidth=0.7)
xlabel('Time lag (\tau)')
ylabel('Partial ACF (correlation)')
title('PACF on zero mean time series');
xlim([0 10])
hold on
yline(conf95,'r--','DisplayName','95% CI')
yline(-conf95,'r--','HandleVisibility','off')
yline(conf99,'g--','DisplayName','99% CI')
yline(-conf99,'g--','HandleVisibility','off')
hold off
grid on
legend
%%
% For original data
figure;
hold on
grid on
for p = 1:10
    ar = aryule(sun,p);
    stem(-ar,'DisplayName',num2str(p));
end
xlabel('Model Order p')
ylabel('Coefficients')
title('Yule Walker coefficients upto AR model order p=10 (original)');
legend

% figure;
% partialcorr(sun,'Method','Yule-Walker','NumLags',10); 

% For zero-mean data
figure;
hold on
grid on
for p = 1:10
    ar = aryule(sun_zmean,p);
    stem(ar,'DisplayName',num2str(p));
end
xlabel('Model Order p')
ylabel('Coefficients')
title('Yule Walker coefficients upto AR model order p=10 (standardised)');
legend

%% minimum description length (MDL) and the Akaike information criterion (AIC)
load sunspot.dat
sun=sunspot(:, 2);
sun = zscore(sun);

p=10;            % the number of estimated parameters (model order)
N = size(sun,1); % the number of available data points
E  = zeros(1,p); % the loss function (typically cumulative squared error)
AIC_c = zeros(1,p);
MDL = zeros(1,p);
AIC = zeros(1,p);
for i =1:10 
    [a,E(i)] = aryule(sun,i); %first component of a is 1 which is our a0.
    MDL(i) = log10(E(i)) + ((i*log10(N))/N); %Minimum description length
    AIC(i) = log10(E(i)) + (2*i)/N; %Akaike information criterion
    AIC_c(i) =  AIC(i) + (((2*i)*(i+1))/(N-i-1)); %Corrected AIC 
end


figure;
hold on;
plot(AIC,'DisplayName','AIC',LineWidth=0.8);
plot(MDL,'DisplayName','MDL',LineWidth=0.8);
plot(AIC_c,'DisplayName','AIC_c',LineWidth=0.8);
plot(log10(E),'--','DisplayName','log10(E)',LineWidth=0.8);
% plot(log(E),'DisplayName','Cumulative Error Squared');
% axis([1 20 0.8 1]); % Overview
% axis([0 20 5.8 6.5]); % Zoom
grid on;
xlabel('Model Order p');
ylabel('Magnitude');
title(['AIC, MDL and Cumulative Error Squared from order p=0 to p=' num2str(p)]);
legend('show');

%% AR model prediction
clear
load sunspot.dat
sun=sunspot(:, 2);
sun=zscore(sun);
% sun = zscore(sun);
M = [1 2 5 10]; % prediction horizons 1,2,5,10
ARn = 2;  % model order

figure;
for n=1:length(M)
    armod1 = ar(sun,1,'yw');
    futures1 = predict(armod1,sun,M(n));
    armod2 = ar(sun,2,'yw');
    futures2 = predict(armod2,sun,M(n));
    armod10 = ar(sun,10,'yw');
    futures10 = predict(armod10,sun,M(n));

    subplot(2,2,n)
    plot(1:length(sun), futures1,'DisplayName','Predicted AR(1)','Color',"#0072BD",'LineWidth',0.7);
    hold on
    plot(1:length(sun), futures2,'DisplayName','Predicted AR(2)','Color',"#77AC30",'LineWidth',0.7);
    plot(1:length(sun), futures10,'DisplayName','Predicted AR(10)','Color',"#7E2F8E",'LineWidth',0.7);
    plot(1:length(sun), sun,'DisplayName','Real Data','Color',"#D95319",'LineWidth',1);
    grid on
    title(['AR(1), AR(2) & AR(10) for m=',num2str(M(n))]);
    xlabel('Sample number N');
    ylabel('Standardised magnitude');
    axis([120 180 -1.5 2.5])
end
legend




