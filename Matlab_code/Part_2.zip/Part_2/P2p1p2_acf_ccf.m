clear all
clc

%% unbiased estimate of the ACF for a 1000-sample realisation
x = randn(1,1000);
Rx = xcorr(x,'unbiased');
tau = -999:999;

figure;
plot(tau,Rx)
grid on
axis([-999 999 -0.5 1.2])
title('unbiased estimate of the ACF for x')
xlabel('\tau (time lag)')
ylabel('signal amplitude')

%% Zoomed in on |tau|<50
figure;
plot(tau,Rx)
grid on
axis([-50 50 -0.2 1.2])
title('unbiased estimate of the ACF for x')
xlabel('\tau (time lag)')
ylabel('signal amplitude')

%% Standard error for 99.7% confidence interval

% at small time lags
stderror = 1/ sqrt(length(x));
error = 3*stderror;
axislen = length(tau);
xhalf = Rx(1000:end);
k = find(xhalf>=error);

figure;
plot(tau,Rx,'DisplayName','ACF estimate')
hold on
plot(tau,error*ones(1,axislen),'r','DisplayName','upper and lower limits')
plot(tau,-error*ones(1,axislen),'r','HandleVisibility','off')
xline(k(4),'k--','DisplayName','\tau bounds')
xline(-k(4),'k--','HandleVisibility','off')
grid on
axis([-999 999 -0.5 1.2])
title('unbiased estimate of the ACF for x')
xlabel('\tau (time lag)')
ylabel('signal amplitude')
legend

%%
order = 9;
y=filter(ones(order,1),[1],x);
Ry = xcorr(y,'unbiased');
figure;
stem(tau,Ry)
grid on
xlabel('\tau (time lag)')
ylabel('signal amplitude')
axis([-20 20 -2 10]);

%% Cross-correlation func

[a,b] = xcorr(y,x,'unbiased');

stem(b,a);
axis([-20 20 -1 2]);
grid on;
grid minor;
xlabel('Tau (Time Lag)');
ylabel('Signal Amplitude');
title('Cross correlation of input and output for 9th order MA filter');



