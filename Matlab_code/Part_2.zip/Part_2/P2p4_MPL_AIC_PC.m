clc
clear

% load the data
load NASDAQ.mat

prices = NASDAQ.Close;
time = NASDAQ.Date;

%% MDL n AIC
prices_norm = zscore(prices);
p=10;                % the number of estimated parameters (model order)
N = size(prices_norm,1);  % the number of available data points
E  = zeros(N,p);     % the loss function (typically cumulative squared error)
x = zeros(N,p); 

for i = 1:p
    ar = aryule(prices_norm(1:N), i);
    x(:,i) = filter(-1*ar(1:end),1,prices_norm);  % simulate by order
end

o = ones(1,p);
% calculate the mean squared error
for i=1:N
    E(i,:) = (x(i,:)-o*prices_norm(i)).^2;   
end
E = sum(E,1);

MDL = log(E(1:p)) + (1:p)*log(N)/N;
AIC = log(E(1:p)) + (1:p)*2/N;
AIC_c = zeros(1,p);

for i=1:p
    AIC_c(i) = AIC(i) + (2*(i))*((i)+1)/(N-(i)-1);
end
% 
% % Normalize??
% MDL = MDL./max(MDL);
% AIC = AIC./max(AIC);
% AIC_c = AIC_c./max(AIC_c);

figure;
subplot(1,2,1)
hold on;
plot(AIC,'DisplayName','AIC',LineWidth=0.8);
plot(MDL,'DisplayName','MDL',LineWidth=0.8);
plot(AIC_c,'DisplayName','AIC_c',LineWidth=0.8)
% plot(log(E),'DisplayName','Cumulative Error Squared');
% axis([1 20 0.8 1]); % Overview
% axis([0 20 5.8 6.5]); % Zoom
grid on;
grid minor;
xlabel('Model Order');
ylabel('Magnitude');
title('AIC, MDL and AIC_c of standardised NASDAQ Data');
legend('show');


%% Partial Corr Func

p=10; % Order 

[arcoefs,E,K] = aryule(prices_norm,p);
pacf = -K;
conf95 = sqrt(2)*erfinv(0.95)/sqrt(924);
conf99 = sqrt(2)*erfinv(0.99)/sqrt(924);

subplot(1,2,2)
stem(pacf,'filled','DisplayName','PCF',LineWidth=0.8)
xlabel('Lag (\tau)');
ylabel('PCF');
title('Partial Correlation of standardised NASDAQ Data');
xlim([1 10])
hold on
yline(conf95,'r--','DisplayName','95% CI')
yline(-conf95,'r--','HandleVisibility','off')
yline(conf99,'g--','DisplayName','99% CI')
yline(-conf99,'g--','HandleVisibility','off')
hold off
grid on
legend

% 
% figure(2)
% stem(1:N_pc,pc,'DisplayName','Empirical PCF');
% hold on;
% stem(1:N_pc,pc_norm,'DisplayName','Zero Mean PCF');
% grid on;
% grid minor;
% xlabel('Tau');
% ylabel('PCF');
% title('Partial Correlation of NASDAQ Data');
% legend('show');

%%

% Using the model of order 1 (standardised)
[a1_std,e_1_std,rc_1_std] = aryule(prices_norm,1); 

%Using the model of order 1 (original)
[a1,e_1,rc_1] = aryule(prices,1); 






