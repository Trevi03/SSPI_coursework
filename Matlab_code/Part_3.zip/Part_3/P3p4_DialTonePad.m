clc
clear all
close all

%% random London landline number

% pair of frequency for each number (row;column)
load("freq_pairs.mat");

landline_num = [0 2 0 randi([0,9],1,8)];

% Compute the discrete time sequence y
f_samp = 32768;  % Hz
N = 0.25*f_samp; % discrete time per press

time_disc = 21*N;     % total discrete time
time_cont = time_disc/f_samp; % total continuous time

y = zeros(1,time_disc); % initialize for complete dial sequence
%%
for i=1:length(landline_num) % for each 0.25s block
    digit = landline_num(i);
    f1 = frequency_pairs(1,digit+1);
    f2 = frequency_pairs(2,digit+1);
    
    for n=0:N-1 % for each n in the 0.25s block
        val = sin(2*pi*f1*n*(1/f_samp)) + sin(2*pi*f2*n*(1/f_samp)); 
        % 2*(i-1)*N for every (block+idle) and (n+1) to access n in each block
        y(2*(i-1)*N+(n+1)) = val;
        % segment(n+1) = val;
    end
    
    % segment_matrix(i,:) = segment;   
end

% segment_time = length(segment_matrix(1,:))/f_samp;
%%

figure;
plot((0:1/f_samp:time_cont-(1/f_samp)),y,'Linewidth',1);
xlim([0 5.25])
title({'Discrete Time Sequence for Landline number'; num2str(landline_num)});
xlabel('Time (s)')
ylabel('Amplitude')

figure;
subplot(1,3,1)
plot((0:1/f_samp:time_cont-(1/f_samp)),y,'Linewidth',1);
xlim([0 0.015])
title('Discrete Time Sequence zoomed in for number 0');
xlabel('Time (s)')
ylabel('Amplitude')


subplot(1,3,2)
plot((0:1/f_samp:time_cont-(1/f_samp)),y,'Linewidth',1);
xlim([0.5 0.515])
title('Discrete Time Sequence zoomed in for number 2');
xlabel('Time (s)')
ylabel('Amplitude')

subplot(1,3,3)
plot((0:1/f_samp:time_cont-(1/f_samp)),y,'Linewidth',1);
xlim([0.25 0.265])
title('Discrete Time Sequence zoomed in for the idle sequence');
xlabel('Time (s)')
ylabel('Amplitude')

% sound(y,f_samp)

%% spectogram

[s,w,t] = spectrogram(y,hann(N),0,N,f_samp,'yaxis');

figure;
subplot(1,2,1)
spectrogram(y,hann(N),0,N,f_samp,'yaxis');
ylim([0 2.5])
title({'Spectrogram of Landline number ' ; num2str(landline_num)});

% FFT of each number
ind = 1;
subplot(1,2,2)
for i=1:2:21
    segment = abs(s(:,i));
    %Plotting the FFT of the segments
    plot(w,20*log10(segment),'Linewidth',1.4,'DisplayName',['Digit ',num2str(landline_num(ind))])
    hold on
    ind = ind+1;
end
title({'FFT of each segments of Landline number ' ; num2str(landline_num)});
xlabel('Frequency (Hz)')
ylabel('Amplitude (dB)')
xlim([600 1800])
legend
grid on

%% Adding noise
var = [0.001 0.1 100];

y_low_var_noise = y + sqrt(var(1)).*randn(1,length(y));
y_med_var_noise = y + sqrt(var(2)).*randn(1,length(y));
y_hi_var_noise = y + sqrt(var(3)).*randn(1,length(y));

figure;
subplot(1,3,1)
plot((0:1/f_samp:time_cont-(1/f_samp)),y_low_var_noise,'Linewidth',1);
xlim([0 5.25])
title('y with low variance noise');
xlabel('Time (s)')
ylabel('Amplitude')

subplot(1,3,2)
plot((0:1/f_samp:time_cont-(1/f_samp)),y_med_var_noise,'Linewidth',1);
xlim([0 5.25])
title('y with medium variance noise');
xlabel('Time (s)')
ylabel('Amplitude')

subplot(1,3,3)
plot((0:1/f_samp:time_cont-(1/f_samp)),y_hi_var_noise,'Linewidth',1);
xlim([0 5.25])
title('y with high variance noise');
xlabel('Time (s)')
ylabel('Amplitude')


figure;
subplot(1,3,1)
spectrogram(y_low_var_noise,hann(N),0,N,f_samp,'yaxis');
ylim([0 2.5])
title('Spectrogram of y with low variance noise');

subplot(1,3,2)
spectrogram(y_med_var_noise,hann(N),0,N,f_samp,'yaxis');
ylim([0 2.5])
title('Spectrogram of y with medium variance noise');

subplot(1,3,3)
spectrogram(y_hi_var_noise,hann(N),0,N,f_samp,'yaxis');
ylim([0 2.5])
title('Spectrogram of y with high variance noise');

%%

[s_low,w_low,t_low] = spectrogram(y_low_var_noise,hanning(N),0,N,f_samp,'yaxis');
[s_med,w_med,t_med] = spectrogram(y_med_var_noise,hanning(N),0,N,f_samp,'yaxis');
[s_hi,w_hi,t_hi] = spectrogram(y_hi_var_noise,hanning(N),0,N,f_samp,'yaxis');

figure;
subplot(1,3,1)
ind = 1;
for i=1:2:21
    segment = abs(s_low(:,i));
    %Plotting the FFT of the segments
    plot(w_low,20*log10(segment),'Linewidth',1.4,'DisplayName',['Digit ',num2str(landline_num(ind))])
    hold on
    ind = ind+1;
end
title({'FFT of each segments of Landline number ' ; num2str(landline_num)});
xlabel('Frequency (Hz)')
ylabel('Amplitude (dB)')
xlim([600 1800])
grid on

subplot(1,3,2)
ind = 1;
for i=1:2:21
    segment = abs(s_med(:,i));
    %Plotting the FFT of the segments
    plot(w_med,20*log10(segment),'Linewidth',1.4,'DisplayName',['Digit ',num2str(landline_num(ind))])
    hold on
    ind = ind+1;
end
title({'FFT of each segments of Landline number ' ; num2str(landline_num)});
xlabel('Frequency (Hz)')
ylabel('Amplitude (dB)')
xlim([600 1800])
grid on

subplot(1,3,3)
ind = 1;
for i=1:2:21
    segment = abs(s_hi(:,i));
    %Plotting the FFT of the segments
    plot(w_hi,20*log10(segment),'Linewidth',1.4,'DisplayName',['Digit ',num2str(landline_num(ind))])
    hold on
    ind = ind+1;
end
title({'FFT of each segments of Landline number ' ; num2str(landline_num)});
xlabel('Frequency (Hz)')
ylabel('Amplitude (dB)')
xlim([600 1800])
grid on
legend


