clc
clear all
close all

%% apply the LSE approach for calculating a

load sunspot.dat;
sun = sunspot(:,2);
sun_zscore=zscore(sun);
x=sun_zscore;

M=length(sun);
[pgm_std f_std]=pgm(sun_zscore);

% for model orders up to 10
for p = 1:10
    % prep matrixes n vectors
    H = zeros(M,p);
    coeff = zeros(p,1);
    % get values via yule-walker
    [a_yw, e_yw(p)] = aryule(sun_zscore,p); % error is variance/MSE
    a_yw = -a_yw(2:end); % correction
    
    for j=1:M % for rows 1 to M
        for i=1:p % for columns 1 to p
            if j-i>0
                H(j,i) = sun_zscore(j-i);
            end
        end
    end
    % use the formula from previous section
    coeff = (inv(H'*H))*H'*x;
    figure(1);
    subplot(2,5,p)
    hold on
    stem(a_yw,'fill','LineWidth',1,'Color',"#FF0000");
    stem(coeff,'LineWidth',1.3,'Color',"#77AC30");   
    title(['Model Order ',num2str(p)]);
    xlabel('Order')
    ylabel('Amplitude')
    if p==10
        legend('Yule-Walker','LSE')
    end

    approx_error(p) = (1/M)*(x'*(x-H*coeff));

    % analysis for optimal order 
    aic(p) = log10(approx_error(p)) + (2*p)/M;   %Akaike information criterion
    aicc(p) =  aic(i) + (((2*p)*(p+1))/(M-p-1)); %Corrected AIC 

    alpha = [1, -coeff'];
    [h_ar_models,w_ar_models]=freqz([1],alpha,M);
    diff(p) = mean(abs(a_yw'-coeff)); %Difference between the two methods

    figure(2);
    subplot (2,5,p)
    plot(f_std,pgm_std,'Color',"#4DBEEE",'Linewidth',1);
    hold on
    plot(w_ar_models/(2*pi),approx_error(p).*(abs(h_ar_models).^2),'k', 'LineWidth', 1.3);
    xlabel('Normalised Frequency');
    ylabel('Magnitude');
    title(['Model order ' num2str(p)]) 
    xlim([0 0.5])
    if p==10
        legend('Periodogram','Model-based')
    end
end

%% Approx error

figure;
subplot(1,2,1)
plot(approx_error,'LineWidth',1,'DisplayName','LSE error')
hold on
plot(e_yw,'LineWidth',1,'DisplayName','Y-W error')
xlabel('model order')
ylabel('Prediction error')
title('Approximation error')
xlim([1 10])
legend
grid on

subplot(1,2,2)
plot(aicc,'LineWidth',1,'DisplayName','AICc')
xlabel('model order')
ylabel('Prediction error')
title('AICc')
xlim([1 10])
grid on

%% behaviour of MSE versus N
p=2;
ind = 1;
for N=10:5:250
    data = sun_zscore(1:N);
    H = zeros(N,p);
    coeff = zeros(p,1);  % optimal coefficient
    for j=1:N % for rows 1 to N
       for i=1:p % for columns 1 to p
           if j-i>0
               H(j,i)=data(j-i);
           end
       end
    end
    x=data;
    coeff = (inv((H'*H)))*H'*x;
    mse(ind) = (1/N)*(x'*(x-H*coeff));
    ind = ind+1;

end

N=10:5:250;
figure;
plot(N,mse,'LineWidth',1)
ylabel('MSE')
xlabel('Data length N')
xlim([10 250])
grid on

